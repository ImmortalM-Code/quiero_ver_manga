COMANDOS = {
    "agregar_mangas" : "o /addm. Agrega mangas de interés con una url de tmo(puedes mandar mas de una url, separadas por espacios) y si el manga existe actualiza los géneros",
    "buscar_mangas" : "o /seam. (NO IMPLEMENTADO)buscar tus mangas de interés guardados en el registro",
    "nuevos_mangas" : "o /newm. busca las nuevas publicaciones de mangas que coincidan con tus mangas de interés",
    "help" : "o /h. muestra todos lo comandos disponibles"
}

BIENVENIDA = """
Bienvenido a MangasUWU %s

Con MangasUWU podras recibir las ultimas notificaciones
de tus mangas en TuMangaOnline.
Para empezar ejecuta el comando /help.
    """

NUEVAS_PUBLICACIONES = """
<b>Titulo : %s </b>
Capitulo : %s
Tipo : %s
Scan : %s
<a href="%s">Enlace a manga</a>
            """